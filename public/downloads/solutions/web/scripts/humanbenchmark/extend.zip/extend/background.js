// Get script name for current page
function getScriptForCurrentPage(url) {
  if (url.includes('/tests/aim')) return 'aim';
  else if (url.includes('/tests/chimp')) return 'chimp';
  else if (url.includes('/tests/memory')) return 'visual';
  else if (url.includes('/tests/number')) return 'number';
  else if (url.includes('/tests/reactiontime')) return 'reaction';
  else if (url.includes('/tests/sequence')) return 'sequence';
  else if (url.includes('/tests/typing')) return 'type';
  else if (url.includes('/tests/verbal-memory')) return 'verbal';
  return null;
}

// Inject script into tab
async function injectScript(tab, scriptName) {
  if (!tab?.id) return;

  try {
    const scriptFile = `scripts/${scriptName}.js`;

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [scriptFile],
      world: "MAIN"
    });

    console.log(`Injected ${scriptFile}`);
  } catch (e) {
    console.warn("Injection failed:", e);
  }
}

// Handle keyboard shortcuts
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  if (command === 'start-script') {
    const scriptName = getScriptForCurrentPage(tab.url);
    if (scriptName) {
      await injectScript(tab, scriptName);
    }
  } else if (command === 'stop-script') {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Alt' }));
      },
      world: "MAIN"
    });
  }
});

// Auto-inject script when page loads
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab?.url) {
    const scriptName = getScriptForCurrentPage(tab.url);
    if (scriptName) {
      await injectScript(tab, scriptName);
    }
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;

  try {
    const scriptName = getScriptForCurrentPage(tab.url);

    if (scriptName) {
      await injectScript(tab, scriptName);
    } else {
      console.log("No matching script for this page");
    }
  } catch (e) {
    console.warn("Injection failed:", e);
  }
});
