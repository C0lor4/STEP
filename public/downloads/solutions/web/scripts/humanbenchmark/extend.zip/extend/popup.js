// Get current active tab
function getCurrentTab() {
    return new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            resolve(tabs[0]);
        });
    });
}

// Update status display
function updateStatus(message) {
    document.getElementById('status').textContent = message;
}

// Save active script to storage
function saveActiveScript(scriptName) {
    chrome.storage.local.set({ activeScript: scriptName });
}

// Get active script from storage
function getActiveScript(callback) {
    chrome.storage.local.get(['activeScript'], (result) => {
        callback(result.activeScript);
    });
}

// Save hotkeys to storage
function saveHotkeys(startKey, stopKey) {
    chrome.storage.local.set({ 
        startHotkey: startKey.toUpperCase(), 
        stopHotkey: stopKey.toUpperCase() 
    });
}

// Get hotkeys from storage
function getHotkeys(callback) {
    chrome.storage.local.get(['startHotkey', 'stopHotkey'], (result) => {
        callback(result.startHotkey || 'S', result.stopHotkey || 'X');
    });
}

// Inject script
async function injectScript(scriptName) {
    try {
        const tab = await getCurrentTab();
        if (!tab?.id) {
            updateStatus('Error: Cannot get tab');
            return;
        }

        const scriptFile = `scripts/${scriptName}.js`;

        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: [scriptFile],
            world: "MAIN"
        });

        updateStatus(`Injected ${scriptName}.js`);

        // Save active script and update button states
        saveActiveScript(scriptName);
        updateButtonStates(scriptName);
    } catch (e) {
        updateStatus(`Injection failed: ${e.message}`);
        console.error('Injection failed:', e);
    }
}

// Update button states
function updateButtonStates(activeScript) {
    document.querySelectorAll('.script-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.script === activeScript) {
            btn.classList.add('active');
        }
    });
}

// Get script name for current page
function getScriptForCurrentPage(url) {
    if (url.includes('/tests/aim')) return 'aim';
    else if (url.includes('/tests/chimp')) return 'chimp';
    else if (url.includes('/tests/memory')) return 'visual';
    else if (url.includes('/tests/number')) return 'number';
    else if (url.includes('/tests/reactiontime')) return 'reaction';
    else if (url.includes('/tests/sequence')) return 'sequence';
    else if (url.includes('/tests/typing')) return 'type';
    else if (url.includes('/tests/verbal-memory')) return 'verbal';
    return null;
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    const startHotkeyInput = document.getElementById('start-hotkey');
    const stopHotkeyInput = document.getElementById('stop-hotkey');

    // Load saved hotkeys
    getHotkeys((startKey, stopKey) => {
        startHotkeyInput.value = startKey;
        stopHotkeyInput.value = stopKey;
    });

    // Handle hotkey input changes
    startHotkeyInput.addEventListener('input', (e) => {
        const value = e.target.value.toUpperCase();
        e.target.value = value;
        saveHotkeys(value, stopHotkeyInput.value);
    });

    stopHotkeyInput.addEventListener('input', (e) => {
        const value = e.target.value.toUpperCase();
        e.target.value = value;
        saveHotkeys(startHotkeyInput.value, value);
    });

    // Add click events to script buttons
    document.querySelectorAll('.script-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const scriptName = btn.dataset.script;
            injectScript(scriptName);
        });
    });

    // Check if current page matches any test
    getCurrentTab().then(tab => {
        if (tab?.url) {
            const matchedScript = getScriptForCurrentPage(tab.url);

            if (matchedScript) {
                updateStatus(`Detected: ${matchedScript} test page`);
            } else {
                updateStatus('Not a test page');
            }
        }
    });

    // Get previously saved active script and update button states
    getActiveScript((activeScript) => {
        if (activeScript) {
            updateButtonStates(activeScript);
        }
    });
});
