# Human Benchmark Assistant

This is a Chrome extension that automates multiple tests on the Human Benchmark website.

## Features

### Aim Test
- Automatically aims and clicks targets
- Fast response for improved efficiency
- Press Alt key to force stop

### Chimp Test
- Automatically records and clicks numbered tiles in order
- Fast response for improved efficiency
- Press Alt key to force stop

### Visual Memory Test
- Automatically memorizes and identifies repeated tiles
- Fast response for improved efficiency
- Press Alt key to force stop

### Number Memory Test
- Automatically memorizes and inputs numbers
- Fast response for improved efficiency
- Press Alt key to force stop

### Reaction Time Test
- Automatically detects "Click!" prompt and clicks immediately
- Millisecond-level response for best results
- Call window.stop() to stop the script

### Sequence Memory Test
- Automatically records and repeats tile sequences
- 3x speed execution for improved efficiency
- Press Alt key to force stop

### Typing Test
- Automatically inputs text content
- Fast response for improved efficiency
- Press Alt key to force stop

### Verbal Memory Test
- Automatically memorizes and identifies repeated words
- Fast response for improved efficiency
- Press Alt key to force stop

## Installation

1. Open Chrome browser and go to `chrome://extensions/`
2. Enable "Developer mode" in the top right corner
3. Click "Load unpacked"
4. Select the folder containing this project (extend folder)
5. Extension is now installed

## Usage

Click the extension icon to open a popup where you can select which script to start. If the current page is a test page, the status bar will show the detected test type.

### Hotkeys

- **Start Script**: Press `Ctrl+Shift+S` (Windows/Linux) or `Command+Shift+S` (Mac) to start the script for the current page
- **Force Stop**: Press `Ctrl+Shift+X` (Windows/Linux) or `Command+Shift+X` (Mac) to force stop the running script

You can also customize these hotkeys in the popup by clicking on the extension icon and setting your preferred keys.

### Aim Test
1. Visit https://humanbenchmark.com/tests/aim
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically aim and click targets
4. Press Alt key to stop the test

### Chimp Test
1. Visit https://humanbenchmark.com/tests/chimp
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically record and click numbers in order
4. Press Alt key to stop the test

### Visual Memory Test
1. Visit https://humanbenchmark.com/tests/memory
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically memorize and identify repeated tiles
4. Press Alt key to stop the test

### Number Memory Test
1. Visit https://humanbenchmark.com/tests/number
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically memorize and input numbers
4. Press Alt key to stop the test

### Reaction Time Test
1. Visit https://humanbenchmark.com/tests/reactiontime
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically detect and click
4. To stop the script, enter `window.stop()` in the console

### Sequence Memory Test
1. Visit https://humanbenchmark.com/tests/sequence
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically record and repeat sequences
4. Press Alt key to stop the test

### Typing Test
1. Visit https://humanbenchmark.com/tests/typing
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically input text content
4. Press Alt key to stop the test

### Verbal Memory Test
1. Visit https://humanbenchmark.com/tests/verbal-memory
2. Click the extension icon in the browser toolbar
3. Start the test, the extension will automatically memorize and identify repeated words
4. Press Alt key to stop the test

## File Structure

- `manifest.json` - Extension configuration file
- `background.js` - Background script, handles extension icon click events
- `popup.html` - Popup page for script selection
- `popup.js` - Popup page logic
- `scripts/aim.js` - Aim test script
- `scripts/chimp.js` - Chimp test script
- `scripts/visual.js` - Visual memory test script
- `scripts/number.js` - Number memory test script
- `scripts/reaction.js` - Reaction time test script
- `scripts/sequence.js` - Sequence test script
- `scripts/type.js` - Typing test script
- `scripts/verbal.js` - Verbal memory test script

## Notes

- This extension is for learning and entertainment purposes only
- Do not use for any unfair competition or cheating
- The extension may stop working after Human Benchmark website updates
