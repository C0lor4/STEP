(() => {
    // 1. 永远返回 visible/focused 状态
    try {
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(document, 'webkitVisibilityState', { get: () => 'visible', configurable: true });
    } catch(e) {}

    document.hasFocus = () => true;
    window.onblur = null;
    document.onvisibilitychange = null;

    // 2. 不屏蔽事件，而是在事件触发时伪造一个 "visible/focus" 状态给回调
    const _winAEL = window.addEventListener.bind(window);
    const _docAEL = document.addEventListener.bind(document);

    function fakeVisibleEvent(type, fn, opts) {
        if (type === 'visibilitychange' || type === 'webkitvisibilitychange') {
            // 让回调收到的 visibilityState 永远是 visible
            return _docAEL(type, function(e) {
                Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
                Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
                fn.call(this, e); // 正常触发，但读到的值是假的
            }, opts);
        }
        if (type === 'blur') {
            // blur 触发时立刻补发一个 focus，让网站以为马上回来了
            return _winAEL(type, function(e) {
                fn.call(this, e);
                setTimeout(() => window.dispatchEvent(new FocusEvent('focus')), 50);
            }, opts);
        }
        return null; // 不是需要处理的类型
    }

    window.addEventListener = function(type, fn, opts) {
        const handled = fakeVisibleEvent(type, fn, opts);
        if (handled !== null) return handled;
        return _winAEL(type, fn, opts);
    };

    document.addEventListener = function(type, fn, opts) {
        const handled = fakeVisibleEvent(type, fn, opts);
        if (handled !== null) return handled;
        return _docAEL(type, fn, opts);
    };

    // 3. 针对 WindowSwitch：不清空方法，而是让它的回调永远收到 'show'
    Object.defineProperty(window, 'WindowSwitch', {
        set(cls) {
            const original = cls.prototype.addEventListenerAll;
            cls.prototype.addEventListenerAll = function(fn) {
                // 包装回调，hidden 状态替换成 show
                return original.call(this, function(status, count) {
                    fn('show', count); // 永远告诉网站是 show（回来了）
                });
            };
            Object.defineProperty(window, 'WindowSwitch', { value: cls, writable: true });
        },
        configurable: true
    });

    Object.defineProperty(window, 'windowSwitch', {
        set(instance) {
            Object.defineProperty(window, 'windowSwitch', { value: instance, writable: true });
        },
        configurable: true
    });

    // 4. 持续模拟鼠标活动
    setInterval(() => {
        document.dispatchEvent(new MouseEvent('mousemove', {
            bubbles: true,
            clientX: Math.random() * window.innerWidth,
            clientY: Math.random() * window.innerHeight
        }));
    }, 5000);

    // 5. addEventListener.toString() 伪装成原生函数，防止被检测篡改
    window.addEventListener.toString = () => 'function addEventListener() { [native code] }';
    document.addEventListener.toString = () => 'function addEventListener() { [native code] }';

    console.log('[FocusBypass] Active');
})();
