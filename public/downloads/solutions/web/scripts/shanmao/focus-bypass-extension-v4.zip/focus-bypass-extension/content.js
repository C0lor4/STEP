(() => {
    // 1. 永远返回 visible/focused 状态
    try {
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(document, 'webkitVisibilityState', { get: () => 'visible', configurable: true });
    } catch(e) {}

    document.hasFocus = () => true;
    window.onblur = null;
    document.onvisibilitychange = null;

    // 2. 让 activeElement 永远返回 IFRAME 节点
    // WindowSwitch 的 blur 检测条件是:
    // if(this.focus && document.activeElement.nodeName != 'IFRAME')
    // 我们让 nodeName 永远是 IFRAME，条件永远不成立
    const fakeIframe = document.createElement('iframe');
    Object.defineProperty(document, 'activeElement', {
        get: () => fakeIframe,
        configurable: true
    });

    // 3. visibilitychange 触发时伪造状态
    const _winAEL = window.addEventListener.bind(window);
    const _docAEL = document.addEventListener.bind(document);

    window.addEventListener = function(type, fn, opts) {
        if (type === 'blur') {
            // blur 触发后立刻补发 focus
            return _winAEL(type, function(e) {
                fn.call(this, e);
                setTimeout(() => window.dispatchEvent(new FocusEvent('focus')), 30);
            }, opts);
        }
        return _winAEL(type, fn, opts);
    };

    document.addEventListener = function(type, fn, opts) {
        if (type === 'visibilitychange' || type === 'webkitvisibilitychange') {
            // 让回调读到的永远是 visible
            return _docAEL(type, function(e) {
                Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
                Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
                fn.call(this, e);
            }, opts);
        }
        return _docAEL(type, fn, opts);
    };

    // 4. WindowSwitch 回调永远收到 show
    Object.defineProperty(window, 'WindowSwitch', {
        set(cls) {
            const original = cls.prototype.addEventListenerAll;
            cls.prototype.addEventListenerAll = function(fn) {
                return original.call(this, function(status, count) {
                    fn('show', count); // 永远是 show
                });
            };
            Object.defineProperty(window, 'WindowSwitch', { value: cls, writable: true });
        },
        configurable: true
    });

    Object.defineProperty(window, 'windowSwitch', {
        set(instance) {
            Object.defineProperty(window, 'windowSwitch', { value: instance, writable: true });
        },
        configurable: true
    });

    // 5. 持续模拟鼠标活动
    setInterval(() => {
        document.dispatchEvent(new MouseEvent('mousemove', {
            bubbles: true,
            clientX: Math.random() * window.innerWidth,
            clientY: Math.random() * window.innerHeight
        }));
    }, 5000);

    // 6. 伪装成原生函数
    window.addEventListener.toString = () => 'function addEventListener() { [native code] }';
    document.addEventListener.toString = () => 'function addEventListener() { [native code] }';

    console.log('[FocusBypass] Active v4');
})();
